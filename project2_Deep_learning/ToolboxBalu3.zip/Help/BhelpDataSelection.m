% Balu Help for Data Selection and Generation
%
%    see also Bds_nostratify        
%             Bds_stratify          
%             Bds_bootstrap         
%             Bds_gaussgen          


