# random_forest

A digit recognizer using Random Forest. Change `train.csv` to make the first column a string to turn it into a nominal attribute.

With `10` trees I got a 94% accuracy and when I changed it to use `100` trees it improved the accuracy to 96%.

It uses weka behind the scenes.
