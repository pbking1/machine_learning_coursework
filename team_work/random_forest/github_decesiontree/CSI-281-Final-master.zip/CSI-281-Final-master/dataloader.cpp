#include "dataloader.h"


using namespace std;

data_Mushroom  ** loadData(string filename, int &size)
{
//	Abandoning implementation for time and using known figures
//	int maxSize = size; 
	int maxSize = 5644;
	ifstream fInput;

	fInput.open(filename);



	data_Mushroom ** tmpArray = new data_Mushroom*[maxSize];
	//data_Mushroom ** arr = NULL;

	int i = 0;
	string tmp;
	int excluded = 0;

	if(fInput.good())
	{
		while(!fInput.eof() && i < maxSize)
		{
			getline(fInput, tmp);

			if (tmp[22] == '?')
			{
				size--;
				cout << "ERROR IN DATA LOADER";
				if (size < maxSize) break;
			}

			else
			{

				tmpArray[i] = new data_Mushroom;

				for(int j = 0; j < 45; j = j + 2)
				{
					switch(j)
					{
					case 0:
						switch (tmp[j])
						{
						case 'p':
							tmpArray[i]->isEdible = false;
							break;
						case 'e':
							tmpArray[i]->isEdible = true;
							break;
						default:
							break;
						}
						break;
					case 2:
						switch(tmp[j])
						{
						case 'b':
							tmpArray[i]->capShape = _CSH_BELL;
							break;
						case 'c':
							tmpArray[i]->capShape = _CSH_CONICAL;
							break;
						case 'x':
							tmpArray[i]->capShape = _CSH_CONVEX;
							break;
						case 'f':
							tmpArray[i]->capShape = _CSH_FLAT;
							break;
						case 'k':
							tmpArray[i]->capShape = _CSH_KNOBBED;
							break;
						case 's':
							tmpArray[i]->capShape = _CSH_SUNKEN;
							break;
						default:
							break;
						}
						break;
					case 4:
						switch(tmp[j])
						{
						case 'f':
							tmpArray[i]->capSurface = _CSU_FIBROUS;
							break;
						case 'g':
							tmpArray[i]->capSurface = _CSU_GROOVES;
							break;
						case 'y':
							tmpArray[i]->capSurface = _CSU_SCALY;
							break;
						case 's':
							tmpArray[i]->capSurface = _CSU_SMOOTH;
							break;
						default:
							break;
						}
						break;
					case 6:
						switch(tmp[j])
						{
						case 'n':
							tmpArray[i]->capColor = _CC_BROWN;
							break;
						case 'b':
							tmpArray[i]->capColor = _CC_BUFF;
							break;
						case 'c':
							tmpArray[i]->capColor = _CC_CINNAMON;
							break;
						case 'g':
							tmpArray[i]->capColor = _CC_GRAY;
							break;
						case 'r':
							tmpArray[i]->capColor = _CC_GREEN;
							break;
						case 'p':
							tmpArray[i]->capColor = _CC_PINK;
							break;
						case 'u':
							tmpArray[i]->capColor = _CC_PURPLE;
							break;
						case 'e':
							tmpArray[i]->capColor = _CC_RED;
							break;
						case 'w':
							tmpArray[i]->capColor = _CC_WHITE;
							break;
						case 'y':
							tmpArray[i]->capColor = _CC_YELLOW;
							break;
						default:
							break;
						}
						break;
					case 8:
						switch (tmp[j])
						{
						case 't':
							tmpArray[i]->bruises = _B_BRUISED;
							break;
						case 'f':
							tmpArray[i]->bruises = _B_NOT_BRUISED;
						default:
							break;
						}
						break;
					case 10:
						switch (tmp[j])
						{
						case 'a':
							tmpArray[i]->odor = _O_ALMOND;
							break;
						case 'l':
							tmpArray[i]->odor = _O_ANISE;
							break;
						case 'c':
							tmpArray[i]->odor = _O_CREOSOTE;
							break;
						case 'y':
							tmpArray[i]->odor = _O_FISHY;
							break;
						case 'f':
							tmpArray[i]->odor = _O_FOUL;
							break;
						case 'm':
							tmpArray[i]->odor = _O_MUSTY;
							break;
						case 'n':
							tmpArray[i]->odor = _O_NONE;
							break;
						case 'p':
							tmpArray[i]->odor = _O_PUNGENT;
							break;
						case 's':
							tmpArray[i]->odor = _O_SPICE;
							break;
						default:
							break;
						}
						break;
					case 12:
						switch (tmp[j])
						{
						case 'a':
							tmpArray[i]->gillAttachment = _GA_ATTACHED;
							break;
						case 'd':
							tmpArray[i]->gillAttachment = _GA_DECENDING;
							break;
						case 'f':
							tmpArray[i]->gillAttachment = _GA_FREE;
							break;
						case 'n':
							tmpArray[i]->gillAttachment = _GA_NOTCHED;
							break;
						default:
							break;
						}
						break;
					case 14:
						switch (tmp[j])
						{
						case 'c':
							tmpArray[i]->gillSpacing = _GSP_CLOSE;
							break;
						case 'w':
							tmpArray[i]->gillSpacing = _GSP_CROWDED;
							break;
						case 'd':
							tmpArray[i]->gillSpacing = _GSP_DISTANT;
							break;
						default:
							break;
						}
						break;
					case 16:
						switch (tmp[j])
						{
						case 'b':
							tmpArray[i]->gillSize = _GSI_BROAD;
							break;
						case 'n':
							tmpArray[i]->gillSize = _GSI_NARROW;
							break;
						default:
							break;
						}
						break;
					case 18:
						switch (tmp[j])
						{
						case 'k':
							tmpArray[i]->gillColor = _GC_BLACK;
							break;
						case 'n':
							tmpArray[i]->gillColor = _GC_BROWN;
							break;
						case 'b':
							tmpArray[i]->gillColor = _GC_BUFF;
							break;
						case 'g':
							tmpArray[i]->gillColor = _GC_GRAY;
							break;
						case 'r':
							tmpArray[i]->gillColor = _GC_GREEN;
							break;
						case 'o':
							tmpArray[i]->gillColor = _GC_ORANGE;
							break;
						case 'p':
							tmpArray[i]->gillColor = _GC_PINK;
							break;
						case 'u':
							tmpArray[i]->gillColor = _GC_PURPLE;
							break;
						case 'e':
							tmpArray[i]->gillColor = _GC_RED;
							break;
						case 'w':
							tmpArray[i]->gillColor = _GC_WHITE;
							break;
						case 'y':
							tmpArray[i]->gillColor = _GC_YELLOW;
							break;
						default:
							break;
						}
						break;
					case 20:
						switch (tmp[j])
						{
						case 'e':
							tmpArray[i]->stalkShape = _SS_ENLARGING;
							break;
						case 't':
							tmpArray[i]->stalkShape = _SS_TAPERING;
							break;
						default:
							break;
						}
						break;
					case 22:
						switch (tmp[j])
						{
						case 'b':
							tmpArray[i]->stalkRoot = _SR_BULBOUS;
							break;
						case 'c':
							tmpArray[i]->stalkRoot = _SR_CLUB;
							break;
						case 'u':
							tmpArray[i]->stalkRoot = _SR_CUP;
							break;
						case 'e':
							tmpArray[i]->stalkRoot = _SR_EQUAL;
							break;
						case 'z':
							tmpArray[i]->stalkRoot = _SR_RHIZOMORPHS;
							break;
						case 'r':
							tmpArray[i]->stalkRoot = _SR_ROOTED;
							break;
						case '?':
							tmpArray[i]->stalkRoot = _SR_MISSING;
							break;
						default:
							break;
						}
						break;
					case 24:
						switch (tmp[j])
						{
						case 'f':
							tmpArray[i]->stalkSurfaceAboveRing = _SSAR_FIBROUS;
							break;
						case 'y':
							tmpArray[i]->stalkSurfaceAboveRing = _SSAR_SCALLY;
							break;
						case 'k':
							tmpArray[i]->stalkSurfaceAboveRing = _SSAR_SILKY;
							break;
						case 's':
							tmpArray[i]->stalkSurfaceAboveRing = _SSAR_SMOOTH;
							break;
						default:
							break;
						}
						break;
					case 26:
						switch (tmp[j])
						{
						case 'f':
							tmpArray[i]->stalkSurfaceBelowRing = _SSBR_FIBROUS;
							break;
						case 'y':
							tmpArray[i]->stalkSurfaceBelowRing = _SSBR_SCALLY;
							break;
						case 'k':
							tmpArray[i]->stalkSurfaceBelowRing = _SSBR_SILKY;
							break;
						case 's':
							tmpArray[i]->stalkSurfaceBelowRing = _SSBR_SMOOTH;
							break;
						default:
							break;
						}
						break;
					case 28:
						switch (tmp[j])
						{
						case 'n':
							tmpArray[i]->stalkColorAboveRing = _SCAR_BROWN;
							break;
						case 'b':
							tmpArray[i]->stalkColorAboveRing = _SCAR_BUFF;
							break;
						case 'c':
							tmpArray[i]->stalkColorAboveRing = _SCAR_CINNAMON;
							break;
						case 'g':
							tmpArray[i]->stalkColorAboveRing = _SCAR_GRAY;
							break;
						case 'o':
							tmpArray[i]->stalkColorAboveRing = _SCAR_ORANGE;
							break;
						case 'p':
							tmpArray[i]->stalkColorAboveRing = _SCAR_PINK;
							break;
						case 'e':
							tmpArray[i]->stalkColorAboveRing = _SCAR_RED;
							break;
						case 'w':
							tmpArray[i]->stalkColorAboveRing = _SCAR_WHITE;
							break;
						case 'y':
							tmpArray[i]->stalkColorAboveRing = _SCAR_YELLOW;
							break;
						default:
							break;
						}
						break;
					case 30:
						switch (tmp[j])
						{
						case 'n':
							tmpArray[i]->stalkColorBelowRing = _SCBR_BROWN;
							break;
						case 'b':
							tmpArray[i]->stalkColorBelowRing = _SCBR_BUFF;
							break;
						case 'c':
							tmpArray[i]->stalkColorBelowRing = _SCBR_CINNAMON;
							break;
						case 'g':
							tmpArray[i]->stalkColorBelowRing = _SCBR_GRAY;
							break;
						case 'o':
							tmpArray[i]->stalkColorBelowRing = _SCBR_ORANGE;
							break;
						case 'p':
							tmpArray[i]->stalkColorBelowRing = _SCBR_PINK;
							break;
						case 'e':
							tmpArray[i]->stalkColorBelowRing = _SCBR_RED;
							break;
						case 'w':
							tmpArray[i]->stalkColorBelowRing = _SCBR_WHITE;
							break;
						case 'y':
							tmpArray[i]->stalkColorBelowRing = _SCBR_YELLOW;
							break;
						default:
							break;
						}
						break;
					case 32:
						switch (tmp[j])
						{
						case 'p':
							tmpArray[i]->veilType = _VT_PARTIAL;
							break;
						case 'u':
							tmpArray[i]->veilType = _VT_UNIVERSAL;
							break;
						default:
							break;
						}
						break;
					case 34:
						switch (tmp[j])
						{
						case 'n':
							tmpArray[i]->veilColor = _VC_BROWN;
							break;
						case 'o':
							tmpArray[i]->veilColor = _VC_ORANGE;
							break;
						case 'w':
							tmpArray[i]->veilColor = _VC_WHITE;
							break;
						case 'y':
							tmpArray[i]->veilColor = _VC_YELLOW;
							break;
						default:
							break;
						}
						break;
					case 36:
						switch (tmp[j])
						{
						case 'n':
							tmpArray[i]->ringNumber = _RN_NONE;
							break;
						case 'o':
							tmpArray[i]->ringNumber = _RN_ONE;
							break;
						case 't':
							tmpArray[i]->ringNumber = _RN_TWO;
						default:
							break;
						}
						break;
					case 38:
						switch (tmp[j])
						{
						case 'c':
							tmpArray[i]->ringType = _RT_COBWEBBY;
							break;
						case 'e':
							tmpArray[i]->ringType = _RT_EVANESCENT;
							break;
						case 'f':
							tmpArray[i]->ringType = _RT_FLARING;
							break;
						case 'l':
							tmpArray[i]->ringType = _RT_LARGE;
							break;
						case 'n':
							tmpArray[i]->ringType = _RT_NONE;
							break;
						case 'p':
							tmpArray[i]->ringType = _RT_PENDANT;
							break;
						case 's':
							tmpArray[i]->ringType = _RT_SHEATHING;
							break;
						case 'z':
							tmpArray[i]->ringType = _RT_ZONE;
							break;
						default:
							break;
						}
						break;
					case 40:
						switch (tmp[j])
						{
						case 'k':
							tmpArray[i]->sporePrintColor = _SPC_BLACK;
							break;
						case 'n':
							tmpArray[i]->sporePrintColor = _SPC_BROWN;
							break;
						case 'b':
							tmpArray[i]->sporePrintColor = _SPC_BUFF;
							break;
						case 'h':
							tmpArray[i]->sporePrintColor = _SPC_CHOCOLATE;
							break;
						case 'r':
							tmpArray[i]->sporePrintColor = _SPC_GREEN;
							break;
						case 'o':
							tmpArray[i]->sporePrintColor = _SPC_ORANGE;
							break;
						case 'u':
							tmpArray[i]->sporePrintColor = _SPC_PURPLE;
							break;
						case 'w':
							tmpArray[i]->sporePrintColor = _SPC_WHITE;
							break;
						case 'y':
							tmpArray[i]->sporePrintColor = _SPC_YELLOW;
							break;
						default:
							break;
						}
						break;
					case 42:
						switch (tmp[j])
						{
						case 'a':
							tmpArray[i]->population = _P_ABUNDANT;
							break;
						case 'c':
							tmpArray[i]->population = _P_CLUSTERED;
							break;
						case 'n':
							tmpArray[i]->population = _P_NUMEROUS;
							break;
						case 's':
							tmpArray[i]->population = _P_SCATTERED;
							break;
						case 'v':
							tmpArray[i]->population = _P_SEVERAL;
							break;
						case 'y':
							tmpArray[i]->population = _P_SOLITARY;
							break;
						default:
							break;
						}
						break;
					case 44:
						switch (tmp[j])
						{
						case 'g':
							tmpArray[i]->habitat = _H_GRASSES;
							break;
						case 'l':
							tmpArray[i]->habitat = _H_LEAVES;
							break;
						case 'm':
							tmpArray[i]->habitat = _H_MEADOW;
							break;
						case 'p':
							tmpArray[i]->habitat = _H_PATHS;
							break;
						case 'u':
							tmpArray[i]->habitat = _H_URBAN;
							break;
						case 'w':
							tmpArray[i]->habitat = _H_WASTE;
							break;
						case 'd':
							tmpArray[i]->habitat = _H_WOODS;
							break;
						default:
							break;
						}
						break;
					default:
						break;
					}
				}
			}
			i++;
		}
	}
	//arr = new data_Mushroom *[size];
	//	abandonded for time's sake.
	/*/
	for (i = 0; i < size; i++)
	{
		for (int j = 0; j < _mr_size; j ++)
		{
			switch (j)
			{
			case _mr_cap_shape:
			case _mr_cap_surface:
			case _mr_cap_color:
			case _mr_bruises:
			case _mr_odor:
			case _mr_gill_attachment:
			case _mr_gill_spacing:
			case _mr_gill_size:
			case _mr_gill_color:
			case _mr_stalk_shape:
			case _mr_stalk_root:
			case _mr_stalk_surface_above_ring:
			case _mr_stalk_surface_below_ring:
			case _mr_stalk_color_above_ring:
			case _mr_stalk_color_below_ring:
			case _mr_veil_type:
			case _mr_veil_color:
			case _mr_ring_number:
			case _mr_ring_type:
			case _mr_spore_print_color:
			case _mr_population:
			case _mr_habitat:
			default:
				break;
			}
		}
	}
	/*/
	if (size != maxSize)
		std::cout << "Size and MaxSize do not match: size = " 
		<< size << " maxSize = " << maxSize << endl;
	fInput.close();

	return tmpArray;
}

input_Mushroom * loadInput(std::string filename = "input1.txt")
{
	ifstream fInput;

	fInput.open(filename);

	string tmp;

	input_Mushroom * mush = new input_Mushroom;

	if(fInput.good())
	{

		getline(fInput, tmp);

		for(int j = 0; j < 43; j = j + 2)
		{
			switch(j)
			{
			case 0:
				switch(tmp[j])
				{
				case 'b':
					mush->capShape = _CSH_BELL;
					break;
				case 'c':
					mush->capShape = _CSH_CONICAL;
					break;
				case 'x':
					mush->capShape = _CSH_CONVEX;
					break;
				case 'f':
					mush->capShape = _CSH_FLAT;
					break;
				case 'k':
					mush->capShape = _CSH_KNOBBED;
					break;
				case 's':
					mush->capShape = _CSH_SUNKEN;
					break;
				default:
					break;
				}
				break;
			case 2:
				switch(tmp[j])
				{
				case 'f':
					mush->capSurface = _CSU_FIBROUS;
					break;
				case 'g':
					mush->capSurface = _CSU_GROOVES;
					break;
				case 'y':
					mush->capSurface = _CSU_SCALY;
					break;
				case 's':
					mush->capSurface = _CSU_SMOOTH;
					break;
				default:
					break;
				}
				break;
			case 4:
				switch(tmp[j])
				{
				case 'n':
					mush->capColor = _CC_BROWN;
					break;
				case 'b':
					mush->capColor = _CC_BUFF;
					break;
				case 'c':
					mush->capColor = _CC_CINNAMON;
					break;
				case 'g':
					mush->capColor = _CC_GRAY;
					break;
				case 'r':
					mush->capColor = _CC_GREEN;
					break;
				case 'p':
					mush->capColor = _CC_PINK;
					break;
				case 'u':
					mush->capColor = _CC_PURPLE;
					break;
				case 'e':
					mush->capColor = _CC_RED;
					break;
				case 'w':
					mush->capColor = _CC_WHITE;
					break;
				case 'y':
					mush->capColor = _CC_YELLOW;
					break;
				default:
					break;
				}
				break;
			case 6:
				switch (tmp[j])
				{
				case 't':
					mush->bruises = _B_BRUISED;
					break;
				case 'f':
					mush->bruises = _B_NOT_BRUISED;
				default:
					break;
				}
				break;
			case 8:
				switch (tmp[j])
				{
				case 'a':
					mush->odor = _O_ALMOND;
					break;
				case 'l':
					mush->odor = _O_ANISE;
					break;
				case 'c':
					mush->odor = _O_CREOSOTE;
					break;
				case 'y':
					mush->odor = _O_FISHY;
					break;
				case 'f':
					mush->odor = _O_FOUL;
					break;
				case 'm':
					mush->odor = _O_MUSTY;
					break;
				case 'n':
					mush->odor = _O_NONE;
					break;
				case 'p':
					mush->odor = _O_PUNGENT;
					break;
				case 's':
					mush->odor = _O_SPICE;
					break;
				default:
					break;
				}
				break;
			case 10:
				switch (tmp[j])
				{
				case 'a':
					mush->gillAttachment = _GA_ATTACHED;
					break;
				case 'd':
					mush->gillAttachment = _GA_DECENDING;
					break;
				case 'f':
					mush->gillAttachment = _GA_FREE;
					break;
				case 'n':
					mush->gillAttachment = _GA_NOTCHED;
					break;
				default:
					break;
				}
				break;
			case 12:
				switch (tmp[j])
				{
				case 'c':
					mush->gillSpacing = _GSP_CLOSE;
					break;
				case 'w':
					mush->gillSpacing = _GSP_CROWDED;
					break;
				case 'd':
					mush->gillSpacing = _GSP_DISTANT;
					break;
				default:
					break;
				}
				break;
			case 14:
				switch (tmp[j])
				{
				case 'b':
					mush->gillSize = _GSI_BROAD;
					break;
				case 'n':
					mush->gillSize = _GSI_NARROW;
					break;
				default:
					break;
				}
				break;
			case 16:
				switch (tmp[j])
				{
				case 'k':
					mush->gillColor = _GC_BLACK;
					break;
				case 'n':
					mush->gillColor = _GC_BROWN;
					break;
				case 'b':
					mush->gillColor = _GC_BUFF;
					break;
				case 'g':
					mush->gillColor = _GC_GRAY;
					break;
				case 'r':
					mush->gillColor = _GC_GREEN;
					break;
				case 'o':
					mush->gillColor = _GC_ORANGE;
					break;
				case 'p':
					mush->gillColor = _GC_PINK;
					break;
				case 'u':
					mush->gillColor = _GC_PURPLE;
					break;
				case 'e':
					mush->gillColor = _GC_RED;
					break;
				case 'w':
					mush->gillColor = _GC_WHITE;
					break;
				case 'y':
					mush->gillColor = _GC_YELLOW;
					break;
				default:
					break;
				}
				break;
			case 18:
				switch (tmp[j])
				{
				case 'e':
					mush->stalkShape = _SS_ENLARGING;
					break;
				case 't':
					mush->stalkShape = _SS_TAPERING;
					break;
				default:
					break;
				}
				break;
			case 20:
				switch (tmp[j])
				{
				case 'b':
					mush->stalkRoot = _SR_BULBOUS;
					break;
				case 'c':
					mush->stalkRoot = _SR_CLUB;
					break;
				case 'u':
					mush->stalkRoot = _SR_CUP;
					break;
				case 'e':
					mush->stalkRoot = _SR_EQUAL;
					break;
				case 'z':
					mush->stalkRoot = _SR_RHIZOMORPHS;
					break;
				case 'r':
					mush->stalkRoot = _SR_ROOTED;
					break;
				case '?':
					mush->stalkRoot = _SR_MISSING;
					break;
				default:
					break;
				}
				break;
			case 22:
				switch (tmp[j])
				{
				case 'f':
					mush->stalkSurfaceAboveRing = _SSAR_FIBROUS;
					break;
				case 'y':
					mush->stalkSurfaceAboveRing = _SSAR_SCALLY;
					break;
				case 'k':
					mush->stalkSurfaceAboveRing = _SSAR_SILKY;
					break;
				case 's':
					mush->stalkSurfaceAboveRing = _SSAR_SMOOTH;
					break;
				default:
					break;
				}
				break;
			case 24:
				switch (tmp[j])
				{
				case 'f':
					mush->stalkSurfaceBelowRing = _SSBR_FIBROUS;
					break;
				case 'y':
					mush->stalkSurfaceBelowRing = _SSBR_SCALLY;
					break;
				case 'k':
					mush->stalkSurfaceBelowRing = _SSBR_SILKY;
					break;
				case 's':
					mush->stalkSurfaceBelowRing = _SSBR_SMOOTH;
					break;
				default:
					break;
				}
				break;
			case 26:
				switch (tmp[j])
				{
				case 'n':
					mush->stalkColorAboveRing = _SCAR_BROWN;
					break;
				case 'b':
					mush->stalkColorAboveRing = _SCAR_BUFF;
					break;
				case 'c':
					mush->stalkColorAboveRing = _SCAR_CINNAMON;
					break;
				case 'g':
					mush->stalkColorAboveRing = _SCAR_GRAY;
					break;
				case 'o':
					mush->stalkColorAboveRing = _SCAR_ORANGE;
					break;
				case 'p':
					mush->stalkColorAboveRing = _SCAR_PINK;
					break;
				case 'e':
					mush->stalkColorAboveRing = _SCAR_RED;
					break;
				case 'w':
					mush->stalkColorAboveRing = _SCAR_WHITE;
					break;
				case 'y':
					mush->stalkColorAboveRing = _SCAR_YELLOW;
					break;
				default:
					break;
				}
				break;
			case 28:
				switch (tmp[j])
				{
				case 'n':
					mush->stalkColorBelowRing = _SCBR_BROWN;
					break;
				case 'b':
					mush->stalkColorBelowRing = _SCBR_BUFF;
					break;
				case 'c':
					mush->stalkColorBelowRing = _SCBR_CINNAMON;
					break;
				case 'g':
					mush->stalkColorBelowRing = _SCBR_GRAY;
					break;
				case 'o':
					mush->stalkColorBelowRing = _SCBR_ORANGE;
					break;
				case 'p':
					mush->stalkColorBelowRing = _SCBR_PINK;
					break;
				case 'e':
					mush->stalkColorBelowRing = _SCBR_RED;
					break;
				case 'w':
					mush->stalkColorBelowRing = _SCBR_WHITE;
					break;
				case 'y':
					mush->stalkColorBelowRing = _SCBR_YELLOW;
					break;
				default:
					break;
				}
				break;
			case 30:
				switch (tmp[j])
				{
				case 'p':
					mush->veilType = _VT_PARTIAL;
					break;
				case 'u':
					mush->veilType = _VT_UNIVERSAL;
					break;
				default:
					break;
				}
				break;
			case 32:
				switch (tmp[j])
				{
				case 'n':
					mush->veilColor = _VC_BROWN;
					break;
				case 'o':
					mush->veilColor = _VC_ORANGE;
					break;
				case 'w':
					mush->veilColor = _VC_WHITE;
					break;
				case 'y':
					mush->veilColor = _VC_YELLOW;
					break;
				default:
					break;
				}
				break;
			case 34:
				switch (tmp[j])
				{
				case 'n':
					mush->ringNumber = _RN_NONE;
					break;
				case 'o':
					mush->ringNumber = _RN_ONE;
					break;
				case 't':
					mush->ringNumber = _RN_TWO;
				default:
					break;
				}
				break;
			case 36:
				switch (tmp[j])
				{
				case 'c':
					mush->ringType = _RT_COBWEBBY;
					break;
				case 'e':
					mush->ringType = _RT_EVANESCENT;
					break;
				case 'f':
					mush->ringType = _RT_FLARING;
					break;
				case 'l':
					mush->ringType = _RT_LARGE;
					break;
				case 'n':
					mush->ringType = _RT_NONE;
					break;
				case 'p':
					mush->ringType = _RT_PENDANT;
					break;
				case 's':
					mush->ringType = _RT_SHEATHING;
					break;
				case 'z':
					mush->ringType = _RT_ZONE;
					break;
				default:
					break;
				}
				break;
			case 38:
				switch (tmp[j])
				{
				case 'k':
					mush->sporePrintColor = _SPC_BLACK;
					break;
				case 'n':
					mush->sporePrintColor = _SPC_BROWN;
					break;
				case 'b':
					mush->sporePrintColor = _SPC_BUFF;
					break;
				case 'h':
					mush->sporePrintColor = _SPC_CHOCOLATE;
					break;
				case 'r':
					mush->sporePrintColor = _SPC_GREEN;
					break;
				case 'o':
					mush->sporePrintColor = _SPC_ORANGE;
					break;
				case 'u':
					mush->sporePrintColor = _SPC_PURPLE;
					break;
				case 'w':
					mush->sporePrintColor = _SPC_WHITE;
					break;
				case 'y':
					mush->sporePrintColor = _SPC_YELLOW;
					break;
				default:
					break;
				}
				break;
			case 40:
				switch (tmp[j])
				{
				case 'a':
					mush->population = _P_ABUNDANT;
					break;
				case 'c':
					mush->population = _P_CLUSTERED;
					break;
				case 'n':
					mush->population = _P_NUMEROUS;
					break;
				case 's':
					mush->population = _P_SCATTERED;
					break;
				case 'v':
					mush->population = _P_SEVERAL;
					break;
				case 'y':
					mush->population = _P_SOLITARY;
					break;
				default:
					break;
				}
				break;
			case 42:
				switch (tmp[j])
				{
				case 'g':
					mush->habitat = _H_GRASSES;
					break;
				case 'l':
					mush->habitat = _H_LEAVES;
					break;
				case 'm':
					mush->habitat = _H_MEADOW;
					break;
				case 'p':
					mush->habitat = _H_PATHS;
					break;
				case 'u':
					mush->habitat = _H_URBAN;
					break;
				case 'w':
					mush->habitat = _H_WASTE;
					break;
				case 'd':
					mush->habitat = _H_WOODS;
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
		}
	}
	fInput.close();

	return mush;
}