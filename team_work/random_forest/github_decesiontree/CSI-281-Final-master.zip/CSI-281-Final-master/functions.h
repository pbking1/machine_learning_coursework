
#include "dataloader.h"
#include "id3.h"
#include "id3tree.h"
#include "mushroom.h"

#include <iostream>


#ifndef FUNCTION_H
#define	FUNCTION_H


bool id3_mushroomTest(); 

#endif	