#include <iostream>

#include "Kaadugal.hpp"

int main(int argc, char * argv[])
{
    Kaadugal::DecisionTree<Kaadugal::AbstractFeatureResponse, Kaadugal::AbstractStatistics, Kaadugal::AbstractLeafData> TestTree(10);

    return 0;
}
