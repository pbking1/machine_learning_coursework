close all
imshow(I,[])