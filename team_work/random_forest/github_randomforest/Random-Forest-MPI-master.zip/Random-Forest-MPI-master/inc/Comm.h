/*
 * Comm.h
 *
 *  Created on: Apr 12, 2012
 *      Author: anthony
 */

#ifndef __Comm_h__
#define __Comm_h__

namespace MessageTag
{
  enum MessageTagEnum
  {
    RowBuffer,
    TreeFinished
  };
}

#endif
