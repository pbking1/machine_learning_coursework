.. -*- mode: rst -*-


This is a community effort, and as such many people have contributed
to it over the years.

History
-------

This project was started in 2010 as a master thesis support project by
Marcel Caraciolo.
In 2011 Bruno Melo, Ricardo Caspirro joined Marcel Caraciolo as leaders
of the project and also made the project as part of Muricoca Labs, a
non-profitable organization specialized in open-source machine learning
projects.  Since then, the project has been updated.


People
------

  * Marcel Caraciolo , 2010

  * Bruno Melo,  2011

  * Ricardo Caspirro , 2011

  * Rodrigo Vieira , 2010 , Wiki Pages and Docummentation Support.

If I forgot anyone, do not hesitate to send me an email to
marcel@muricoca.com and I'll include you in the list.

