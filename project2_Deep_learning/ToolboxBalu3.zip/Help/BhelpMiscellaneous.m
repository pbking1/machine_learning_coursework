% Balu Help for Miscellaneous Functions
%
%    see also clt                   
%             howis                 
%             enterpause            
%             compare
%             imi



