#include "functions.h"


int main()
{
	bool cont = true;
	while (cont)
	{
		cont = id3_mushroomTest();
	}
}