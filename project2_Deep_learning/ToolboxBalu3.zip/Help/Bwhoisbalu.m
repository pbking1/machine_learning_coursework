% Bwhoisbalu
%
% Toolbox: Balu
%    If you don't know Balu you must watch this video.
%
% D.Mery, PUC-DCC, Jun. 2008
% http://dmery.ing.puc.cl
%
I = imread('Balu.jpg');
imshow(I)
title('Balu and Mowgli')
clc

disp('Balu  :  Kid, I only got so much room up in this noggin...')
disp('         and it''s fillin'' up fast!')
disp('Mowgli:  You just don''t understand.')
disp('Balu  :  All right. How''s about layin'' it out for me.')
disp(' ')
disp('If you want to learn who is Balu, please see this video in youtube:');
disp(' ')
disp('http://www.youtube.com/watch?v=9ogQ0uge06o ...');
disp(' ')
disp('... and sing this song:')
disp(' ')
disp('   The simple bare necessities')
disp('   Forget about your worries and your strife')
disp('   I mean the bare necessities')
disp('   Old Mother Nature''s recipes')
disp('   That brings the bare necessities of life')
disp(' ')
disp('   And don''t spend your time lookin'' around')
disp('   For something you want that can''t be found')
disp('   When you find out you can live without it')
disp('   And go along not thinkin'' about it')
disp('   I''ll tell you something true')
