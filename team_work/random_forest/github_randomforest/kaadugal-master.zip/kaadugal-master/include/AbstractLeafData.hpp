#ifndef _ABSTRACTLEAFDATA_HPP_
#define _ABSTRACTLEAFDATA_HPP_

namespace Kaadugal
{
    class AbstractLeafData
    {
	
    };
} // namespace Kaadugal

#endif // _ABSTRACTLEAFDATA_HPP_
