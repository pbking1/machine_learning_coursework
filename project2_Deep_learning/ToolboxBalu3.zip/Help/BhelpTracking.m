% Balu Help for Tracking with Geometry Constraints
%
%    see also Btr_demo              
%             Btr_join              
%             Btr_merge             
%             Btr_plot              
%             Btr_sfm               
%             Btr_sfseq             
%             Btr_sift2             
%             Btr_siftn             
%             Btr_analysis          
%             Btr_windows           
%             Btr_classify          
%             Btr_detection         


