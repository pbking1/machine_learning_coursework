% Dummy file called by Bfx_gui
% It selects all features of X.
function selec = Bfs_all(X,d,options)
m = size(X,2);
selec = (1:m)';