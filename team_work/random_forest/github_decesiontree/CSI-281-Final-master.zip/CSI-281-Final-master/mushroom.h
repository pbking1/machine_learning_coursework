/* ***       Author:  Team Same
     *  Last Update:  February 25, 2014
     *        Class:  CSI-281
     *     Filename:  
     *			mushroom.h
     *  Description:
     *			contains types for mushrooms
     *  
     *  Certification of Authenticity:
     *     I certify that this assignment is entirely our own work.
     **********************************************************************/

#ifndef __MUSHROOM__
#define __MUSHROOM__


/*
 * Traits that show edibility are closer to 1 and traits that show non-edibility are closer to 9
*/

enum _mushroom_fields{
	//_mr_edible = 0,
	_mr_cap_shape,
	_mr_cap_surface,
	_mr_cap_color,
	_mr_bruises,
	_mr_odor,
	_mr_gill_attachment,
	_mr_gill_spacing,
	_mr_gill_size,
	_mr_gill_color,
	_mr_stalk_shape,
	_mr_stalk_root,
	_mr_stalk_surface_above_ring,
	_mr_stalk_surface_below_ring,
	_mr_stalk_color_above_ring,
	_mr_stalk_color_below_ring,
	_mr_veil_type,
	_mr_veil_color,
	_mr_ring_number,
	_mr_ring_type,
	_mr_spore_print_color,
	_mr_population,
	_mr_habitat,
	_mr_size
};

enum _cap_shape{
	
	_CSH_ERROR	= -1,
	_CSH_BELL	= 0,
	_CSH_CONICAL,
	_CSH_CONVEX,
	_CSH_FLAT,
	_CSH_KNOBBED,
	_CSH_SUNKEN,
	_CSH_SIZE
};

enum _cap_surface{

	_CSU_ERROR	= -1,
	_CSU_FIBROUS = 0,
	_CSU_GROOVES,
	_CSU_SCALY,
	_CSU_SMOOTH,
	_CSU_SIZE
};

enum _cap_color{
	_CC_ERROR	= -1,
	_CC_BROWN	= 0,
	_CC_BUFF,
	_CC_CINNAMON,
	_CC_GRAY,
	_CC_GREEN, 
	_CC_PINK,
	_CC_PURPLE,
	_CC_RED,
	_CC_WHITE,
	_CC_YELLOW,
	_CC_SIZE
};

enum _bruises{
	_B_ERROR	    = -1,
	_B_BRUISED	= 0,
	_B_NOT_BRUISED,
	_B_SIZE
};

enum _odor{
	_O_ERROR		= -1,
	_O_ALMOND	= 0,
	_O_ANISE,
	_O_CREOSOTE,
	_O_FISHY,
	_O_FOUL,
	_O_MUSTY,
	_O_NONE,
	_O_PUNGENT,
	_O_SPICE,
	_O_SIZE
};

enum _gill_attachment{
	_GA_ERROR	 = -1,
	_GA_ATTACHED  = 0,
	_GA_DECENDING,
	_GA_FREE,
	_GA_NOTCHED,
	_GA_SIZE
};

enum _gill_spacing{
	_GSP_ERROR	= -1,
	_GSP_CLOSE   = 0,
	_GSP_CROWDED,
	_GSP_DISTANT,
	_GSP_SIZE
};

enum _gill_size{
	_GSI_ERROR  = -1,
	_GSI_BROAD  = 0,
	_GSI_NARROW,
	_GSI_SIZE
};

enum _gill_color{
	_GC_ERROR	= -1,
	_GC_BLACK	= 0,
	_GC_BROWN,
	_GC_BUFF,
	_GC_CHOCOLATE,
	_GC_GRAY,
	_GC_GREEN,
	_GC_ORANGE,
	_GC_PINK,
	_GC_PURPLE,
	_GC_RED,
	_GC_WHITE,
	_GC_YELLOW,
	_GC_SIZE
};

enum _stalk_shape{
	_SS_ERROR		= -1,
	_SS_ENLARGING	= 0,
	_SS_TAPERING,
	_SS_SIZE
};

enum _stalk_root{
	_SR_ERROR	= -1,
	_SR_BULBOUS	= 0,
	_SR_CLUB,
	_SR_CUP,
	_SR_EQUAL,
	_SR_RHIZOMORPHS,
	_SR_ROOTED,
	_SR_MISSING,
	_SR_SIZE
};

enum _stalk_surface_above_ring{
	_SSAR_ERROR		= -1,
	_SSAR_FIBROUS	= 0,
	_SSAR_SCALLY,
	_SSAR_SILKY,
	_SSAR_SMOOTH,
	_SSAR_SIZE
};

enum _stalk_surface_below_ring{
	_SSBR_ERROR		= -1,
	_SSBR_FIBROUS	= 0,
	_SSBR_SCALLY,
	_SSBR_SILKY,
	_SSBR_SMOOTH,
	_SSBR_SIZE
};

enum _stalk_color_above_ring{
	_SCAR_ERROR	= -1,
	_SCAR_BROWN	= 0,
	_SCAR_BUFF,
	_SCAR_CINNAMON,
	_SCAR_GRAY,
	_SCAR_ORANGE, 
	_SCAR_PINK,
	_SCAR_RED,
	_SCAR_WHITE,
	_SCAR_YELLOW,
	_SCAR_SIZE
};

enum _stalk_color_below_ring{
	_SCBR_ERROR	= -1,
	_SCBR_BROWN	= 0,
	_SCBR_BUFF,
	_SCBR_CINNAMON,
	_SCBR_GRAY,
	_SCBR_ORANGE, 
	_SCBR_PINK,
	_SCBR_RED,
	_SCBR_WHITE,
	_SCBR_YELLOW,
	_SCBR_SIZE
};

enum _veil_type{
	_VT_ERROR	= -1,
	_VT_PARTIAL	= 0,
	_VT_UNIVERSAL,
	_VT_SIZE
};

enum _veil_color{
	_VC_ERROR	= -1,
	_VC_BROWN	= 0,
	_VC_ORANGE,
	_VC_WHITE,
	_VC_YELLOW,
	_VC_SIZE
};

enum _ring_number{
	_RN_ERROR	= -1,
	_RN_NONE		= 0,
	_RN_ONE,
	_RN_TWO,
	_RN_SIZE
};

enum _ring_type{
	_RT_ERROR	= -1,
	_RT_COBWEBBY	= 0,
	_RT_EVANESCENT,
	_RT_FLARING,
	_RT_LARGE,
	_RT_NONE,
	_RT_PENDANT,
	_RT_SHEATHING,
	_RT_ZONE,
	_RT_SIZE
};

enum _spore_print_color{
	_SPC_ERROR	= -1,
	_SPC_BLACK	= 0,
	_SPC_BROWN,
	_SPC_BUFF,
	_SPC_CHOCOLATE,
	_SPC_GREEN,
	_SPC_ORANGE,
	_SPC_PURPLE,
	_SPC_WHITE,
	_SPC_YELLOW,
	_SPC_SIZE
};

enum _population{
	_P_ERROR		= -1,
	_P_ABUNDANT  = 0,
	_P_CLUSTERED,
	_P_NUMEROUS,
	_P_SCATTERED,
	_P_SEVERAL,
	_P_SOLITARY,
	_P_SIZE
};

enum _habitat{
	_H_ERROR = -1,
	_H_GRASSES	= 0,
	_H_LEAVES,
	_H_MEADOW,
	_H_PATHS,
	_H_URBAN,
	_H_WASTE,
	_H_WOODS,
	_H_SIZE
};

typedef struct{

	bool isEdible;
	_cap_shape capShape;
	_cap_surface capSurface;
	_cap_color capColor;
	_bruises bruises;
	_odor odor;
	_gill_attachment gillAttachment;
	_gill_spacing gillSpacing;
	_gill_size gillSize;
	_gill_color gillColor;
	_stalk_shape stalkShape;
	_stalk_root stalkRoot;
	_stalk_surface_above_ring stalkSurfaceAboveRing;
	_stalk_surface_below_ring stalkSurfaceBelowRing;
	_stalk_color_above_ring stalkColorAboveRing;
	_stalk_color_below_ring stalkColorBelowRing;
	_veil_type veilType;
	_veil_color veilColor;
	_ring_number ringNumber;
	_ring_type ringType;
	_spore_print_color sporePrintColor;
	_population population;
	_habitat habitat;

} data_Mushroom;

typedef struct{

	_cap_shape capShape;
	_cap_surface capSurface;
	_cap_color capColor;
	_bruises bruises;
	_odor odor;
	_gill_attachment gillAttachment;
	_gill_spacing gillSpacing;
	_gill_size gillSize;
	_gill_color gillColor;
	_stalk_shape stalkShape;
	_stalk_root stalkRoot;
	_stalk_surface_above_ring stalkSurfaceAboveRing;
	_stalk_surface_below_ring stalkSurfaceBelowRing;
	_stalk_color_above_ring stalkColorAboveRing;
	_stalk_color_below_ring stalkColorBelowRing;
	_veil_type veilType;
	_veil_color veilColor;
	_ring_number ringNumber;
	_ring_type ringType;
	_spore_print_color sporePrintColor;
	_population population;
	_habitat habitat;

} input_Mushroom;

#endif