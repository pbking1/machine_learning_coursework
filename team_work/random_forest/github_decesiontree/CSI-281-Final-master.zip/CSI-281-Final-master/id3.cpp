#include "id3.h"


using namespace std;

id3tree * id3_createNewTree(data_Mushroom ** data)
{
	id3tree * tree = new id3tree();

	tree->generateFromData(data)


}

id3tree * id3_loadNewTree(std::string filename)
{
	id3tree * tree = new id3tree();
	
	ifstream input(filename);

	if(input.good())
		tree->generateFromFile(input);
}

int id3_saveCurrentTree(id3tree * tree, std::string file)
{
	ofstream output(file);


	if(output.good())
		tree->saveCurrentTree(output);

	return 0;
}

int id3_printTree(id3tree * tree)
{
	tree->outputTree(cout);

	return 0;
}

bool id3_checkMushroom(id3tree *tree, input_Mushroom * mush)
{
	return tree->mshIsEdible(mush);
}
