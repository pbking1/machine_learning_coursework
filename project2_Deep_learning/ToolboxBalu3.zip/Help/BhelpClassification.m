% Balu Help for Classification
%
%    see also Bcl_adaboost          
%             Bcl_bayes2            
%             Bcl_bagging           
%             Bcl_boosting          
%             Bcl_boostVJ           
%             Bcl_det21             
%             Bcl_det22             
%             Bcl_dmin              
%             Bcl_knn               
%             Bcl_lda               
%             Bcl_maha              
%             Bcl_pegasos           
%             Bcl_pnn               
%             Bcl_qda               
%             Bcl_svm               
%             Bcl_svmplus           
%             Bcl_nnglm             
%             Bcl_exe               
%             Bcl_structure         
%             Bcl_ensemble          
%             Bcl_dcs               
%             Bcl_weakc             
%             Bcl_tree              
%             Bcl_nbnnxi            
%             Bcl_balu              
%             Bcl_gui
%             Bcl_build



