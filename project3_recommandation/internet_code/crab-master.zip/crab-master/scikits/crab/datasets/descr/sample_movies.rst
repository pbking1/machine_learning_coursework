sample_movies data set was collected by the book called 
Programming the Collective Intelligence by Toby Segaran 

Notes
-----
This data set consists of
	* n ratings with (1-5) from n users to n movies.