% howis(x)
%
% Toolbox: Balu
%    How is x? it displays min, max, size, class of x.
%
% D.Mery, PUC-DCC, Jul 2009
% http://dmery.ing.puc.cl
%

function howis(x)
fprintf('%s\n',['min   = ' num2str(min(x(:)))])
fprintf('%s\n',['max   = ' num2str(max(x(:)))])
fprintf('%s\n',['size  = ' num2str(size(x))])
fprintf('%s\n',['class = ' class(x)])

