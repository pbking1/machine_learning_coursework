#ifndef _ABSTRACTSTATISTICS_HPP_
#define _ABSTRACTSTATISTICS_HPP_

namespace Kaadugal
{
    class AbstractStatistics
    {
	
    };
} // namespace Kaadugal

#endif // _ABSTRACTSTATISTICS_HPP_

