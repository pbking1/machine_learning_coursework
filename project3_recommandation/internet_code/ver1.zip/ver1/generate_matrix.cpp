#include<iostream>
#include<cmath>
#include<fstream>
#include<cstdio>
using namespace std;
double train_data[103][24984];

int main(){
	char buffer[256];
	ifstream fin("train.txt");
	double c;
	int id, a, b;
	int i, j;
	while(!fin.eof()){
		fin.getline(buffer, 50);
		sscanf(buffer, "%d %d %d %lf", &id, &a, &b, &c);
		train_data[b][a] = c;
	}
	fin.close();
	
	ofstream fout("matrix_data.csv");
	if(!fout)
		cout<<"error";
	for(int i = 1; i < 102; i++){
		for(int j = 1; j < 24984; j++){
			if(j != 24983)
				fout << train_data[i][j] <<",";
			else
				fout << train_data[i][j];
		}
		fout<<endl;
	}
	fout.close();

	ofstream fout1("small_matrix_data.csv");
	if(!fout1)
		cout<<"error";
	for(int i = 1; i < 20; i++){
		for(int j = 1; j < 20; j++){
			if(j != 4)
				fout1 << train_data[i][j] << ",";
			else
				fout1 << train_data[i][j];
		}
		fout1<<endl;
	}
	fout1.close();
	return 0;
}
