
#ifndef LL_H
#define LL_H

template<class T>
class LinkedList
{
private:
	template <class T>
	struct Node
	{
		T		*	mData;
		Node<T> *	mNext;
		Node<T> *	mPrev;

		Node()
		{
			mData	= NULL;
			mNext	= NULL;
			mPrev	= NULL;
		}

		Node(T *data)
		{
			mData	= data;
			mNext	= NULL;
			mPrev	= NULL;
		}
	};

	Node<T> *mHead, *mTail;
	int mCount;

public:
	LinkedList();
	~LinkedList();

	inline int getcount() {return mCount;};

	void	addNode(T *data);
	void	clear();
	T		*getData(int index);
	bool	isExist(T *index);
	void	removeHead();
};

#endif

