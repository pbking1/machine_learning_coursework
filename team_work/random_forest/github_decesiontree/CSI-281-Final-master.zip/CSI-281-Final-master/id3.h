#include "id3tree.h"
#include <math.h>

#ifndef ID3_H
#define	ID3_H


id3tree * id3_createNewTree(data_Mushroom ** data);

id3tree * id3_loadNewTree(std::string filename);

int id3_saveCurrentTree(id3tree * tree, std::string file);

int id3_printTree(id3tree * tree);

bool id3_checkMushroom(id3tree * tree,input_Mushroom * mush);

#endif
