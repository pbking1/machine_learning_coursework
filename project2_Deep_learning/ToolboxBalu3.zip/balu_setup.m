function balu_setup()
%cp_setup()
%   install cp_toolbox
%

[cp_root_path, b] = fileparts( mfilename('fullpath') ) ;
[root_path, b] = fileparts( cp_root_path ) ;
path = root_path ;

addpath( fullfile( cp_root_path ) );
addpath( fullfile( cp_root_path, 'Classification') ) ;
addpath( fullfile( cp_root_path, 'Clustering') ) ;
addpath( fullfile( cp_root_path, 'DataSelectionAndGeneration') ) ;
addpath( fullfile( cp_root_path, 'FeatureAnalysis') ) ;
addpath( fullfile( cp_root_path, 'FeatureExtraction') ) ;
addpath( fullfile( cp_root_path, 'FeatureSelection') ) ;
addpath( fullfile( cp_root_path, 'FeatureTransformation') ) ;
addpath( fullfile( cp_root_path, 'Help') ) ;
addpath( fullfile( cp_root_path, 'ImageProcessing') ) ;
addpath( fullfile( cp_root_path, 'ImagesAndData') ) ;
addpath( fullfile( cp_root_path, 'InputOutput') ) ;
addpath( fullfile( cp_root_path, 'Miscellaneous') ) ;
addpath( fullfile( cp_root_path, 'MultiView') ) ;
addpath( fullfile( cp_root_path, 'PerformanceEvaluation') ) ;
addpath( fullfile( cp_root_path, 'SequenceProcessing') ) ;
addpath( fullfile( cp_root_path, 'Tracking') ) ;


fprintf('balu_toolbox added!\n');
end
