#include "functions.h"



using namespace std;


bool id3_mushroomTest()
{
	data_Mushroom ** mushrooms = NULL;
	char input = 'z';
	string file;
	bool notree = true, result;

	id3tree * tree = NULL;

	cout << "ID3 Mushroom Test. \n\nDo you want to:\n(c)reate new tree\n(l)oad tree from file\n\n";

	cin >> input;

	switch(input)
	{
	case 'c':
		cout << "\n\nWhat is the file where that contains the dataset?: ";
		cin >> file;
		mushrooms = loadData(file,5644);
		tree = id3_createNewTree(mushrooms);
		break;
		notree = false;
	case 'l':
		cout << "\n\nWhat is the file where that contains the dataset?: ";
		cin >> file;
		tree = id3_loadNewTree(file);
		notree = false;
		break;
	default:
		break;
	}

	if(!notree)
	{
		while(!notree)
		{
			cout << "\n\nDo you want to:\n(p)rint the tree\n(s)ave tree to file\n(t)est a mushroom against this tree\n(l)eave this dialouge\n\n";

			cin >> input;

			switch(input)
			{
			case 's':
				cout << "\n\nWhat is the file that you want saved?: ";
				cin >> file;
				id3_saveCurrentTree(tree,file);
				break;
			case 'p':
				id3_printTree(tree);
				break;
			case 't':
				cout << "\n\nWhat is the file where that contains the data?: ";
				cin >> file;
				result = id3_checkMushroom(loadInput(file));
				if(result)
					cout << "\nyou can eat that mushroom\n";
				else
					cout << "\nyou can't eat that mushroom\n";
				break;
			case 'l':
				notree = true;
				break;
			default:
				break;
			}
		}
	}

	if(mushrooms != NULL)
		delete mushrooms;
	if(tree != NULL)
		delete tree;

	cout << "\n\nDo you want to run this script again? (y/n): ";

	cin >> input;

	if(input == 'y')
		return true;

	return false;
};