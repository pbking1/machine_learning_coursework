#include "linkedlist.h"
#include "mushroom.h"
#include "dataloader.h"
#include <iostream>
#include <stdarg.h>

#ifndef ID3TREE_H
#define	ID3TREE_H


class id3tree
{
private:
	struct Node
	{
		LinkedList<Node *> mBranches;
		int mData;
		int mLevel;

		Node()
		{
			mData = -1;
		};

		Node(int cargo, int level)
		{
			mData = cargo;
			mLevel = level;
		};

		~Node()
		{
			void deleteLevel();
		};
	};

	Node *rootNode;

	void createLevel(Node *curNode, data_Mushroom **data, int size, _mushroom_fields * ignoreList);
	void deleteTree();
	void deleteTree(Node *node);
	void makeLeafNode(Node* leafNode, int value);

public:
	id3tree();
	~id3tree();
	int generateFromData(data_Mushroom ** data, int size, _mushroom_fields * ignoreList = NULL);
	int generateFromData(data_Mushroom ** data, Node * cur);
	int generateFromFile(std::ifstream &input);
	int outputTree(std::ostream &out);
	int outputTree(std::ostream &out, Node * cur);
	int saveCurrentTree(std::ofstream &out);
	int saveCurrentTree(std::ofstream &out, Node * cur);
	bool mshIsEdible(input_Mushroom * input);
};

bool allSameClass(data_Mushroom ** data);

double calc_entropy(_mushroom_fields curField, data_Mushroom  ** data, int size);

double calc_gain();

double log2(double n);


#endif
