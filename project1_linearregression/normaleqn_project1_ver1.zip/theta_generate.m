data = load('train.txt');
X = data(:, 3:386);
y = data(:, 2);
m = length(y);
m2 = size(X);
fprintf('The number of the case is %d\n', m);
fprintf('The number of feature is %d\n', m2);
theta = normaleqn(X, y);
m3 = length(theta);
fprintf('The number of the theta is %d\n', m3);

data2 = load('test.txt');
feat = data2(:, 2:385);
m3 = size(feat);
fprintf('The number of test feature is %d\n', m3);
result = feat * theta;
%result
linen = data2(:, 1);
%linen
m4 = length(result);
m5 = length(linen);
fprintf('The number of y is %d and the length of the id is %d\n', m4, m5);

csvwrite('aaa', [linen result])
