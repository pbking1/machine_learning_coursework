ID3-ALGORITHM
=============

Decision Tree Algorithm(C++,Python)
For simple tests.
