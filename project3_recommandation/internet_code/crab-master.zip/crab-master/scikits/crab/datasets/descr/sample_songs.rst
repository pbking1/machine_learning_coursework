Sample_song data set was collected by the e-book called 
A Programmer's Guide to Data Mining - http://guidetodatamining.com

Notes
-----
This data set consists of
	* 49 ratings with (1-5) from 8 users to 8 movies.