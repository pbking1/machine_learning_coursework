% clt
%
% Toolbox: Balu
%    Clear all variables and close all windows
%
% D.Mery, PUC-DCC, Apr. 2008
% http://dmery.ing.puc.cl


%s = input('Closing all windows and deleting all variables [y/n]?','s');
%if (s=='y')
clear all
close all
disp('All windows closed & all variables deleted.')
drawnow
%else
%    disp('Clear and close interrupted.')
%end
