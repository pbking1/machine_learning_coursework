#include "id3tree.h"

#include <stdlib.h>

using namespace std;

id3tree::id3tree()
{
	rootNode = NULL;
}

id3tree::~id3tree()
{
	deleteTree();
}

void id3tree::createLevel(Node *curNode, data_Mushroom **data, int size, _mushroom_fields * ignoreList)
{
	if (allSameClass(data))
	{
		makeLeafNode(curNode, data[1]->isEdible);
	}
}

void id3tree::deleteTree()
{
	deleteTree(rootNode);
}

void id3tree::deleteTree(Node *node)
{
	while (node->mBranches.getcount != 0) 
	{
		deleteTree(*node->mBranches.getData(0));
		node->mBranches.removeHead();
	}
	delete node;
}


int id3tree::generateFromData(data_Mushroom ** data, int size, _mushroom_fields * ignoreList = NULL)
{
	/*
	if(rootNode == NULL)
	{
		if(allSameClass(data))
		{
			if(data[0]->isEdible == true)
				rootNode = new Node(1,0);
			else
				rootNode = new Node(0,0);
		}

		else
		{

		}
		return 0;
	}
	return 1;
	*/

	if (rootNode == NULL)
		rootNode = new Node;

	createLevel(rootNode, data, size, ignoreList);

	return int();
}

int id3tree::generateFromFile(std::ifstream &input)
{
	if(rootNode == NULL)
	{
		string tmp = "";
		int level = 0, curlevel = 0;
		Node *precur, *cur;
		getline(input,tmp);

		rootNode = new Node(atoi(tmp.c_str()),level);

		cur = rootNode;
		precur = cur;

		if(rootNode->mBranches.getcount() != 0)
		{
			while(!input.eof())
			{
				getline(input,tmp);

				curlevel = tmp.length() - 1;


				if(curlevel > level)
				{

				}
				else if(curlevel - level == 2)
				{
					tmp = tmp[curlevel];

					cur->mBranches.addNode(new Node(atoi(tmp.c_str()),curlevel));
				}
				else
				{
					tmp = tmp[curlevel];

					precur->mBranches.addNode(new Node(atoi(tmp.c_str()),curlevel));

					cur = precur->mBranches.getData(precur->mBranches.getcount() - 1);
				}
				

			}
		}
		return 0;
	}
	return 1;
}

int id3tree::outputTree(std::ostream &out)
{
	if(rootNode != NULL)
	{
		if(rootNode->mBranches.getcount() == 0)
			out << rootNode->mData;
		else
		{
			for(int i = 0; i < rootNode->mLevel; i++)
				out << ' ';
			out << rootNode->mData;

			for(int i = 0; i < rootNode->mBranches.getcount(); i++)
				outputTree(out,rootNode->mBranches.getData(i));
		}
		return 0;
	}

	return 1;
}

int id3tree::outputTree(std::ostream &out, Node * cur)
{
	if(cur != NULL)
	{
		if(cur->mBranches.getcount() == 0)
		{
			for(int i = 0; i < cur->mLevel; i++)
				out << ' ';

			out << cur->mData;
		}
		else
		{
			for(int i = 0; i < cur->mLevel; i++)
				out << ' ';
			out << cur->mData;

			for(int i = 0; i < cur->mBranches.getcount(); i++)
				outputTree(out,cur->mBranches.getData(i));
		}
		return 0;
	}

	return 1;
}

int id3tree::saveCurrentTree(std::ofstream &out)
{
	if(rootNode != NULL)
	{
		if(rootNode->mBranches.getcount() == 0)
			out << rootNode->mData;
		else
		{
			for(int i = 0; i < rootNode->mLevel; i++)
				out << ' ';
			out << rootNode->mData;

			for(int i = 0; i < rootNode->mBranches.getcount(); i++)
				saveCurrentTree(out,rootNode->mBranches.getData(i));
		}
		return 0;
	}

	return 1;
}

int id3tree::saveCurrentTree(std::ofstream &out, Node * cur)
{
	if(cur != NULL)
	{
		if(cur->mBranches.getcount() == 0)
		{
			for(int i = 0; i < cur->mLevel; i++)
				out << ' ';

			out << cur->mData;
		}
		else
		{
			for(int i = 0; i < cur->mLevel; i++)
				out << ' ';
			out << cur->mData;

			for(int i = 0; i < cur->mBranches.getcount(); i++)
				saveCurrentTree(out,cur->mBranches.getData(i));
		}
		return 0;
	}

	return 1;
}

bool id3tree::mshIsEdible(input_Mushroom * input)
{
}

bool allSameClass(data_Mushroom ** data)
{
	bool sclass = true;
	
	for(int i = 0; i < 5644; i++)
	{
		if(data[0]->isEdible != data[i]->isEdible)
		{
			sclass = false;
		}
	}
	return sclass;
}

double calc_entropy(_mushroom_fields curField, data_Mushroom  ** data, int size)
{
	int		numClasses;
	double	fraction = 0;
	double	entropy	= 0;
	data_Mushroom * dataPtr;
	double *numerators;
	double *denominators;

	switch (curField)
	{
	case _mr_cap_shape:
		numClasses = _CSH_SIZE;
		break;
	case _mr_cap_surface:
		numClasses = _CSU_SIZE;
		break;
	case _mr_cap_color:
		numClasses = _CC_SIZE;
		break;
	case _mr_bruises:
		numClasses = _B_SIZE;
		break;
	case _mr_odor:
		numClasses = _O_SIZE;
		break;
	case _mr_gill_attachment:
		numClasses = _GA_SIZE;
		break;
	case _mr_gill_spacing:
		numClasses = _GSP_SIZE;
		break;
	case _mr_gill_size:
		numClasses = _GSI_SIZE;
		break;
	case _mr_gill_color:
		numClasses = _GC_SIZE;
		break;
	case _mr_stalk_shape:
		numClasses = _SS_SIZE;
		break;
	case _mr_stalk_root:
		numClasses = _SR_SIZE;
		break;
	case _mr_stalk_surface_above_ring:
		numClasses =  _SSAR_SIZE;
		break;
	case _mr_stalk_surface_below_ring:
		numClasses = _O_SIZE;
		break;
	case _mr_stalk_color_above_ring:
		numClasses = _SCAR_SIZE;
		break;
	case _mr_stalk_color_below_ring:
		numClasses = _SCBR_SIZE;
		break;
	case _mr_veil_type:
		numClasses = _VT_SIZE; 
		break;
	case _mr_veil_color:
		numClasses = _VC_SIZE;
		break;
	case _mr_ring_number:
		numClasses = _RN_SIZE;
		break;
	case _mr_ring_type:
		numClasses = _RT_SIZE; 
		break;
	case _mr_spore_print_color:
		numClasses = _SPC_SIZE;
		break;
	case _mr_population:
		numClasses = _P_SIZE; 
		break;
	case _mr_habitat:
		numClasses = _H_SIZE; 
		break;
	default:
		break;
	}

	numerators = new double[numClasses];
	denominators = new double[numClasses];
	for (int j = 0; j < numClasses; j++)
	{
		numerators[j] = 0;
		denominators[j] = 0;
	}

	for (int i = 0; i < size; i++)
	{
		switch (curField)
		{
		case _mr_cap_shape:
			denominators[data[i]->capShape]++;
			if (data[i]->isEdible)
				numerators[data[i]->capShape]++;
			break;
		case _mr_cap_surface:
			denominators[data[i]->capSurface]++;
			if (data[i]->isEdible)
				numerators[data[i]->capSurface]++;
			break;
		case _mr_cap_color:
			denominators[data[i]->capColor]++;
			if (data[i]->isEdible)
				numerators[data[i]->capColor]++;
			break;
		case _mr_bruises:
			denominators[data[i]->bruises]++;
			if (data[i]->isEdible)
				numerators[data[i]->bruises]++;
			break;
		case _mr_odor:
			denominators[data[i]->odor]++;
			if (data[i]->isEdible)
				numerators[data[i]->odor]++;
			break;
		case _mr_gill_attachment:
			denominators[data[i]->gillAttachment]++;
			if (data[i]->isEdible)
				numerators[data[i]->gillAttachment]++;
			break;
		case _mr_gill_spacing:
			denominators[data[i]->gillSpacing]++;
			if (data[i]->isEdible)
				numerators[data[i]->gillSpacing]++;
			break;
		case _mr_gill_size:
			denominators[data[i]->gillSize]++;
			if (data[i]->isEdible)
				numerators[data[i]->gillSize]++;
			break;
		case _mr_gill_color:
			denominators[data[i]->gillColor]++;
			if (data[i]->isEdible)
				numerators[data[i]->gillColor]++;
			break;
		case _mr_stalk_shape:
			denominators[data[i]->stalkShape]++;
			if (data[i]->isEdible)
				numerators[data[i]->stalkShape]++;
			break;
		case _mr_stalk_root:
			denominators[data[i]->stalkRoot]++;
			if (data[i]->isEdible)
				numerators[data[i]->stalkRoot]++;
			break;
		case _mr_stalk_surface_above_ring:
			denominators[data[i]->stalkSurfaceAboveRing]++;
			if (data[i]->isEdible)
				numerators[data[i]->stalkSurfaceAboveRing]++;
			break;
		case _mr_stalk_surface_below_ring:
			denominators[data[i]->stalkSurfaceBelowRing]++;
			if (data[i]->isEdible)
				numerators[data[i]->stalkSurfaceBelowRing]++;
			break;
		case _mr_stalk_color_above_ring:
			denominators[data[i]->stalkColorAboveRing]++;
			if (data[i]->isEdible)
				numerators[data[i]->stalkColorAboveRing]++;
			break;
		case _mr_stalk_color_below_ring:
			denominators[data[i]->stalkColorBelowRing]++;
			if (data[i]->isEdible)
				numerators[data[i]->stalkColorBelowRing]++;
			break;
		case _mr_veil_type:
			denominators[data[i]->veilType]++;
			if (data[i]->isEdible)
				numerators[data[i]->veilType]++;
			break;
		case _mr_veil_color:
			denominators[data[i]->veilColor]++;
			if (data[i]->isEdible)
				numerators[data[i]->veilColor]++;
			break;
		case _mr_ring_number:
			denominators[data[i]->ringNumber]++;
			if (data[i]->isEdible)
				numerators[data[i]->ringNumber]++;
			break;
		case _mr_ring_type:
			denominators[data[i]->ringType]++;
			if (data[i]->isEdible)
				numerators[data[i]->ringType]++;
			break;
		case _mr_spore_print_color:
			denominators[data[i]->sporePrintColor]++;
			if (data[i]->isEdible)
				numerators[data[i]->sporePrintColor]++;
			break;
		case _mr_population:
			denominators[data[i]->population]++;
			if (data[i]->isEdible)
				numerators[data[i]->population]++;
			break;
		case _mr_habitat:
			denominators[data[i]->habitat]++;
			if (data[i]->isEdible)
				numerators[data[i]->habitat]++;
			break;
		default:
			break;
		}
	}

	for (int k = 0; k < numClasses; k++)
	{
		fraction = (numerators[k]/denominators[k]);
		entropy += (-fraction * log2(fraction));
	}

	delete [] numerators;
	delete [] denominators;
	return entropy;
}

double calc_gain()
{
}


// convert to log base 2
double log2(double n)
{
	return log(n)/log(2);
}
