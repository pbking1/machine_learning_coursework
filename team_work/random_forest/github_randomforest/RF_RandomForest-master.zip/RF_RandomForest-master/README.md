RF_RandomForest
===============
General purpose random forest implementation

Who is the author?
------------------
 * Martin Simon <martiinsiimon@gmail.com>

What the project license?
-------------------------
See file LICENSE. If any part is taken from other source, it's mentined in file header

How to build/run?
-----------------
See file INSTALL

Is this project documented? Where?
----------------------------------
Take a look into `doc` directory

Is this the latest version?
---------------------------
For the latest version take a look into project's github repository http://github.com/martiinsiimon/RF_RandomForest.git
