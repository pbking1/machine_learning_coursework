function imshowc(varargin)
close all
imshow(varargin{:})