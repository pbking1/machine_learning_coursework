## description 
- an implement of decision tree classifier

## Learning Step by Step
'''bash
train -z -n 1 -v -f 700 data/small.txt
'''

## TO
- random forest
- gbdt 

