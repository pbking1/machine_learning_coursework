#ifndef _ABSTRACTFEATURERESPONSE_HPP_
#define _ABSTRACTFEATURERESPONSE_HPP_

namespace Kaadugal
{
    class AbstractFeatureResponse
    {
	
    };
} // namespace Kaadugal

#endif // _ABSTRACTFEATURERESPONSE_HPP_
