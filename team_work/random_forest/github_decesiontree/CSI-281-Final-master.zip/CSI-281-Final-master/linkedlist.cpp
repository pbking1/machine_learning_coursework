
#include "linkedlist.h"

#ifndef LL_CPP
#define LL_CPP

template <class T>
LinkedList<T>::LinkedList()
{
	mHead	= NULL;
	mTail	= NULL;
	mCount	= 0;
}


template <class T>
LinkedList<T>::LinkedList()
{
	clear();
}

template <class T>
void LinkedList<T>::addNode(T *data)
{
	Node<T> *tmp;
	Node<T> *newNode;

	newNode = new Node<T>(data);
	tmp = mHead;
	if (mHead == NULL)
	{
		mHead = newNode;
		mTail = newNode;
		mCount++;
		return;
	}
	else if (mHead->mData > data)
	{
		newNode->mNext = mHead;
		mHead->mPrev = newNode;
		mHead = newNode;
		mCount++;
		return;
	}
	else if (mTail->mData < data)
	{
		
		newNode->mPrev = mTail;
		mTail->mNext = newNode;
		mTail = newNode;
		mCount++;
		return;
	}
	
	//if not head and not tail
	else while (tmp->mData > data)
	{
		tmp = tmp->mNext;
	}
	newNode->mPrev = tmp;
	newNode->mNext = tmp->mNext;
	newNode->mNext->mPrev = newNode;
	tmp->mNext = newNode;
	mCount++;
}


template <class T>
void LinkedList<T>::clear()
{
	while (mHead != NULL)
	{
		removeHead();
	}
}


// WILL RETURN NULL IF OUT OF BOUNDS
template <class T>
T LinkedList<T>::getData(int index)
{
	Node<T> *tmp;
	tmp = mHead;
	for (int i = 0; i < pos && tmp != NULL; i++)
	{
		 tmp = tmp->mNext
	}
	return tmp;
}

template <class T>
bool LinkedList<T>::isExist(T index)
{
	Node<T> *tmp;
	tmp = mHead;
	while (tmp != NULL)
	{
		if (tmp->mData == index)
		{
			return true;
		}
		tmp = tmp->mNext;
	}
	return false;
}

template <class T>
void LinkedList<T>::removeHead()
{
	Node<T> *tmp;
	tmp = mHead;
	if (mHead->mNext != NULL)
		mHead = mHead->mNext;
	tmp->mNext = NULL;
	delete tmp;
	mCount--;
}

#endif