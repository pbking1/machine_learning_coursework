RandomForest
============

For High Performance Computing course project in Fall 2012.
Hadoop implementation for Random Forest Classifier.
