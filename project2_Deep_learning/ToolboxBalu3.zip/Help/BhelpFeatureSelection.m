% Balu Help for Feature Selection
%
%    see also Bfs_balu              
%             Bfs_clean             
%             Bfs_exsearch          
%             Bfs_fosmod            
%             Bfs_lsef              
%             Bfs_noposition        
%             Bfs_random            
%             Bfs_ransac            
%             Bfs_rank              
%             Bfs_sfs               
%             Bfs_sfscorr           
%             Bfs_build 
