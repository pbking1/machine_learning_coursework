Balu Toolbox Matlab version 3.1
Domingo Mery
e-mail: dmery@ing.puc.cl
http://dmery.ing.puc.cl
Departamento de Ciencia de la Computacion
Pontificia Universidad Catolica de Chile
(c) 2008-2011


Balu  :  Kid, I only got so much room up in this noggin...
         and it's fillin' up fast!
Mowgli:  You just don't understand.
Balu  :  All right. How's about layin' it out for me.


-------------------------------------------------------
Please see an updated version of this help in:

http://dmery.ing.puc.cl/index.php/balu/
--------------------------------------------------------

I'd like to hear about any bugs that you find, or suggestions for 
improvements.
