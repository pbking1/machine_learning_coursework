https://archive.ics.uci.edu/ml/datasets.html
split -l 3133 abalone.data
