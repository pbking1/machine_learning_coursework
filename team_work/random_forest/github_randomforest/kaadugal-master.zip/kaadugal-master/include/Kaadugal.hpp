#ifndef _KAADUGAL_HPP_
#define _KAADUGAL_HPP_

#include "DecisionForest.hpp"

#endif // _KAADUGAL_HPP_
