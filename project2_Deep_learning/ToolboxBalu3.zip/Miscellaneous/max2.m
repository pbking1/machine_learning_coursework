function s = max2(x)
s = max(x(:));